import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class SearchBookServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String search = request.getParameter("search");

        response.sendRedirect("show?search=" + search);
    }
}
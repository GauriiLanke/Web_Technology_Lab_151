import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class AddBookServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO ebookshop VALUES (?,?,?,?,?)");

            ps.setInt(1, Integer.parseInt(request.getParameter("id")));
            ps.setString(2, request.getParameter("title"));
            ps.setString(3, request.getParameter("author"));
            ps.setDouble(4, Double.parseDouble(request.getParameter("price")));
            ps.setInt(5, Integer.parseInt(request.getParameter("qty")));

            ps.executeUpdate();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("show");
    }
}
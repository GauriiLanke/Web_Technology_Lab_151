import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;

public class ShowBooksServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String search = request.getParameter("search");

        out.println("<html><head>");
        out.println("<title>Book Store</title>");
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");

        out.println("<style>");
        out.println("body{background:#f5f7fa}");
        out.println(".card{border-radius:12px}");
        out.println("</style>");

        out.println("</head><body>");

        out.println("<div class='container mt-4'>");
        out.println("<div class='card p-4 shadow'>");

        out.println("<h2 class='text-center mb-4'>Book Store</h2>");

        // SEARCH
        out.println("<form action='search' method='get' class='mb-3'>");
        out.println("<div class='input-group'>");
        out.println("<input name='search' class='form-control' placeholder='Search'>");
        out.println("<button class='btn btn-dark'>Search</button>");
        out.println("</div></form>");

        // ADD FORM
        out.println("<form action='add' method='post' class='mb-4'>");

        out.println("<div class='row g-2'>");
        out.println("<div class='col'><input name='id' class='form-control' placeholder='ID'></div>");
        out.println("<div class='col'><input name='title' class='form-control' placeholder='Title'></div>");
        out.println("<div class='col'><input name='author' class='form-control' placeholder='Author'></div>");
        out.println("<div class='col'><input name='price' class='form-control' placeholder='Price'></div>");
        out.println("<div class='col'><input name='qty' class='form-control' placeholder='Qty'></div>");
        out.println("</div>");

        out.println("<button class='btn btn-success mt-2'>Add</button>");
        out.println("</form>");

        try {
            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM ebookshop";

            if (search != null && !search.isEmpty()) {
                query += " WHERE book_title LIKE '%" + search + "%'";
            }

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            out.println("<table class='table table-bordered'>");
            out.println("<thead class='table-dark'>");
            out.println("<tr>");
            out.println("<th>ID</th>");
            out.println("<th>Title</th>");
            out.println("<th>Author</th>");
            out.println("<th>Price</th>");
            out.println("<th>Qty</th>");
            out.println("<th>Action</th>");
            out.println("</tr>");
            out.println("</thead>");

            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getInt(1) + "</td>");
                out.println("<td>" + rs.getString(2) + "</td>");
                out.println("<td>" + rs.getString(3) + "</td>");
                out.println("<td>" + rs.getDouble(4) + "</td>");
                out.println("<td>" + rs.getInt(5) + "</td>");

                out.println("<td>");
                out.println("<a href='delete?id=" + rs.getInt(1) + "' class='btn btn-danger btn-sm'>Delete</a>");
                out.println("</td>");

                out.println("</tr>");
            }

            out.println("</table>");

            con.close();

        } catch (Exception e) {
            out.println(e);
        }

        out.println("</div></div></body></html>");
    }
}